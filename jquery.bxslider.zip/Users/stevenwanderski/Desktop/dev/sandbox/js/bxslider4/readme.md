#Introducing bxSlider 4.0
##Completely re-written and now fully responsive

Please note that v4.0 is currently in beta as I test, test, test, and get a fresh new doc site up and running.

In the meantime feel free to check out the source and play around. I cannot provide support yet, but will do my best once the new site is up and running. Everything seems to be running pretty well as of right now..

Look for the full release very soon!